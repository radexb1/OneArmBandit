using System;

class MainClass
{
    public static void Main(string[] args)
    {
      
        string[] symbole = { "Truskawka", "Cytryna", "Malina", "Jabłko", "Arbuz", "Borówka" };
        Random rand = new Random();
        Console.WriteLine("Podaj swoje imie");
        string name = Console.ReadLine();
        Console.WriteLine("Ile monet chciałbyś włożyć " + name);
        int money = int.Parse(Console.ReadLine());
        for (int i = 0; i< money; i++)
        {
          int jeden = rand.Next(0, symbole.Length);
          int dwa = rand.Next(0, symbole.Length);
          int trzy = rand.Next(0, symbole.Length);

          Console.Write("|" + symbole[jeden]);
          Console.Write("|" + symbole[dwa]);
          Console.Write("|" + symbole[trzy]);
          Console.WriteLine();
         if (jeden == dwa && dwa == trzy) 
         {
           Console.WriteLine("You win");
           break;
         }  else 
         {
          Console.WriteLine("You lose");
         }
         
        }
        
        

        // for (int i = 0; i <= money; i++)
        // {
        //     for (int j = 0; j < rand.Next(symbole.Length); j++)

        //     {
        //         Console.WriteLine("|" + symbole[j]);
        //     }
        //     Console.WriteLine();

        // }
    
    }//nie dziala xD no to

    // to musi byc 5 losowan po 3 owoce
} //tera

